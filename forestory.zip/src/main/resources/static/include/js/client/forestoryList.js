$(function(){
	$("#insertFormBtn").click(function(){
		location.href = "client/forestory/forestoryInsertForm";
	})
})