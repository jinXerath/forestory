package com.forestory.common.vo;

public class DeleteIt {

}
