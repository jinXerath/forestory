package com.forestory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForestoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
