package com.forestory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForestoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForestoryApplication.class, args);
	}

}
